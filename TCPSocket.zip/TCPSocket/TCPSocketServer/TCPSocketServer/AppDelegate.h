//
//  AppDelegate.h
//  TCPSocketServer
//
//  Created by scasy_wang on 16/10/20.
//  Copyright © 2016年 scasy_wang. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

